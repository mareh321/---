use crate::value::{display_number, Calc, Value};
use roxmltree::{Document, Node, ParsingOptions};
use std::collections::HashMap;

const WS: &str = "http://schemas.mathsoft.com/worksheet30";
const ML: &str = "http://schemas.mathsoft.com/math30";
type Xml<'a, 'input> = Node<'a, 'input>;

#[derive(Debug)]
enum Expr {
    Literal(Value),
    Ref(usize),
    Unary(String, Box<Expr>),
    Binary(String, Box<Expr>, Box<Expr>),
}

impl Expr {
    fn eval(&self, cache: &[Option<Calc<Value>>]) -> Calc<Value> {
        match self {
            Self::Literal(value) => Ok(*value),
            Self::Ref(index) => cache[*index]
                .as_ref()
                .ok_or("зависимость ещё не рассчитана")?
                .as_ref()
                .copied()
                .map_err(|_| format!("ошибка в зависимой формуле #{}", index + 1)),
            Self::Unary(op, arg) => arg.eval(cache)?.unary(op),
            Self::Binary(op, left, right) => left.eval(cache)?.binary(op, right.eval(cache)?),
        }
    }
}

pub struct Region {
    pub source_id: String,
    pub label: String,
    pub text: Option<String>,
    input_unit: Option<Value>,
    formula: Option<Calc<Expr>>,
    display_unit: Option<(String, Expr)>,
}

pub struct Sheet {
    pub regions: Vec<Region>,
    cache: Vec<Option<Calc<Value>>>,
    overrides: Vec<Option<Value>>,
    dependents: Vec<Vec<usize>>,
    dirty: Vec<usize>,
    queued: Vec<bool>,
}

fn named(node: Xml<'_, '_>, ns: &str, name: &str) -> bool {
    node.has_tag_name((ns, name))
}

fn elements<'a, 'input>(node: Xml<'a, 'input>) -> impl Iterator<Item = Xml<'a, 'input>> {
    node.children().filter(Node::is_element)
}

fn kind<'input>(node: Xml<'_, 'input>) -> &'input str {
    node.tag_name().name()
}

fn identifier(node: Xml<'_, '_>) -> Calc<String> {
    if !named(node, ML, "id") {
        return Err(format!(
            "идентификатор типа <{}> не поддерживается",
            kind(node)
        ));
    }
    let name = node
        .text()
        .filter(|name| !name.is_empty())
        .ok_or("пустое имя")?;
    if let Some(subscript) = node.attribute("subscript") {
        return Ok(format!("{name}.{subscript}"));
    }
    Ok(name.into())
}

fn definition_name(target: Xml<'_, '_>) -> Calc<String> {
    if named(target, ML, "function") {
        return identifier(elements(target).next().ok_or("у функции нет имени")?);
    }
    if named(target, ML, "apply") {
        let mut children = elements(target);
        if children.next().is_some_and(|op| named(op, ML, "indexer")) {
            return identifier(children.next().ok_or("у массива нет имени")?);
        }
    }
    identifier(target)
}

fn expression(
    node: Xml<'_, '_>,
    names: &HashMap<String, usize>,
    deps: &mut Vec<usize>,
    depth: usize,
) -> Calc<Expr> {
    if depth > 128 || node.tag_name().namespace() != Some(ML) {
        return Err("неподдерживаемое пространство имён или глубина формулы".into());
    }
    let mut nested = |child| expression(child, names, deps, depth + 1);
    match kind(node) {
        "real" => {
            let data = node.text().ok_or("пустое число")?.trim();
            let number = data
                .parse::<f64>()
                .map_err(|_| format!("неверное число {data}"))?;
            Ok(Expr::Literal(Value::scalar(number)?))
        }
        "id" => {
            let name = identifier(node)?;
            if let Some(&index) = names.get(&name) {
                deps.push(index);
                return Ok(Expr::Ref(index));
            }
            Value::constant(&name)
                .map(Expr::Literal)
                .ok_or_else(|| format!("неизвестное имя {name}"))
        }
        "parens" => {
            let children: Vec<_> = elements(node).collect();
            match children.as_slice() {
                [child] => nested(*child),
                _ => Err("неверная структура скобок".into()),
            }
        }
        "apply" => {
            let mut children = elements(node);
            let operator = children.next().ok_or("нет операции")?;
            if operator.tag_name().namespace() != Some(ML) {
                return Err("неподдерживаемое пространство имён операции".into());
            }
            let id = named(operator, ML, "id")
                .then(|| identifier(operator))
                .transpose()?;
            let op = id.as_deref().unwrap_or_else(|| kind(operator));
            if id.is_some() && names.contains_key(op) {
                return Err(format!(
                    "вызов пользовательской функции {op} не поддерживается"
                ));
            }
            let args: Vec<_> = children.collect();
            match (id.is_some(), op, args.as_slice()) {
                (false, "plus" | "minus" | "mult" | "scale" | "div" | "pow", [left, right]) => {
                    Ok(Expr::Binary(
                        op.into(),
                        Box::new(nested(*left)?),
                        Box::new(nested(*right)?),
                    ))
                }
                (false, "neg" | "minus" | "sqrt" | "absval", [arg]) => {
                    let op = if op == "absval" { "abs" } else { op };
                    Ok(Expr::Unary(op.into(), Box::new(nested(*arg)?)))
                }
                (true, "sin" | "cos" | "tan" | "abs" | "sqrt" | "exp" | "ln", [arg]) => {
                    Ok(Expr::Unary(op.into(), Box::new(nested(*arg)?)))
                }
                _ => Err(format!("неподдерживаемая операция или аргументы: {op}")),
            }
        }
        other => Err(format!("неподдерживаемое выражение <{other}>")),
    }
}

fn unit_label(node: Xml<'_, '_>) -> String {
    // Use the XML text to make the most common, single-symbol unit override readable.
    if let Ok(name) = identifier(node) {
        return name;
    }
    "ед. листа".into()
}

fn input_unit(node: Xml<'_, '_>, names: &HashMap<String, usize>) -> Option<Value> {
    if named(node, ML, "real") {
        return Value::scalar(1.).ok();
    }
    let children: Vec<_> = elements(node).collect();
    if let [op, number, unit] = children.as_slice() {
        if named(node, ML, "apply")
            && (named(*op, ML, "scale") || named(*op, ML, "mult"))
            && named(*number, ML, "real")
        {
            let mut deps = Vec::new();
            let unit = expression(*unit, names, &mut deps, 0).ok()?;
            if deps.is_empty() {
                return unit.eval(&[]).ok().filter(|unit| unit.number != 0.);
            }
        }
    }
    None
}

fn position(region: Xml<'_, '_>, key: &str, fallback: &str) -> Calc<f64> {
    let number = region
        .attribute(key)
        .or_else(|| region.attribute(fallback))
        .unwrap_or("0");
    number
        .parse::<f64>()
        .ok()
        .filter(|n| n.is_finite())
        .ok_or_else(|| format!("некорректная координата {key}={number}"))
}

impl Sheet {
    pub fn import(xml: &str) -> Calc<Self> {
        let document = Document::parse_with_options(
            xml,
            ParsingOptions {
                nodes_limit: 500_000,
                ..ParsingOptions::default()
            },
        )
        .map_err(|error| error.to_string())?;
        let root = document.root_element();
        if !named(root, WS, "worksheet") {
            return Err("ожидается лист XMCD Mathcad с пространством имён worksheet30".into());
        }
        let container = elements(root)
            .find(|node| named(*node, WS, "regions"))
            .ok_or("лист не содержит блока regions")?;
        let nested_effect = container.descendants().find(|node| {
            named(*node, ML, "globalDefine")
                || (node.is_element()
                    && node.tag_name().namespace() == Some(WS)
                    && matches!(
                        kind(*node),
                        "reference" | "include" | "area" | "component" | "solveBlock"
                    ))
        });
        if let Some(node) = nested_effect {
            return Err(format!(
                "лист содержит <{}>, который может менять порядок или значения расчётов",
                kind(node)
            ));
        }

        let mut ordered = Vec::new();
        for region in elements(container) {
            if !named(region, WS, "region") {
                return Err(format!("неподдерживаемый элемент листа <{}>", kind(region)));
            }
            ordered.push((
                position(region, "align-y", "top")?,
                position(region, "left", "left")?,
                region,
            ));
        }
        ordered.sort_by(|a, b| a.0.total_cmp(&b.0).then(a.1.total_cmp(&b.1)));
        let size = ordered.len();
        let mut sheet = Self {
            regions: Vec::with_capacity(size),
            cache: vec![None; size],
            overrides: vec![None; size],
            dependents: vec![Vec::new(); size],
            dirty: Vec::new(),
            queued: vec![false; size],
        };
        let mut names = HashMap::new();
        for (_, _, node) in ordered {
            sheet.import_region(node, &mut names)?;
        }
        Ok(sheet)
    }

    fn import_region(&mut self, node: Xml<'_, '_>, names: &mut HashMap<String, usize>) -> Calc<()> {
        let index = self.regions.len();
        let mut region = Region {
            source_id: node.attribute("region-id").unwrap_or("?").into(),
            label: String::new(),
            text: None,
            input_unit: None,
            formula: None,
            display_unit: None,
        };
        let mut deps = Vec::new();
        let content = elements(node).find(|child| !named(*child, WS, "rendering"));
        match content.map(kind) {
            Some("text") => {
                let text = content
                    .ok_or("нет текста")?
                    .descendants()
                    .filter(Node::is_text)
                    .filter_map(|part| part.text())
                    .map(str::trim)
                    .filter(|s| !s.is_empty())
                    .collect::<Vec<_>>()
                    .join(" ");
                region.text = Some(text);
            }
            Some("math") => {
                let math = content.ok_or("нет формулы")?;
                let mut statement = math;
                loop {
                    statement = elements(statement)
                        .find(|child| child.tag_name().namespace() == Some(ML))
                        .ok_or_else(|| {
                            format!("регион {} не содержит формулы math30", region.source_id)
                        })?;
                    if !named(statement, ML, "provenance") {
                        break;
                    }
                }
                let children: Vec<_> = elements(statement).collect();
                let disabled = math.attribute("disable-calc") == Some("true");
                match (kind(statement), children.as_slice()) {
                    ("define", [target, expr, ..]) => {
                        let name = definition_name(*target)?;
                        region.label = name.clone();
                        let result = if disabled {
                            Err("вычисление отключено в исходном листе".into())
                        } else if named(*target, ML, "function") {
                            Err("пользовательская функция".into())
                        } else if named(*target, ML, "apply") {
                            Err("запись в элемент массива не поддерживается".into())
                        } else {
                            let result = expression(*expr, names, &mut deps, 0);
                            if result.is_ok() {
                                region.input_unit = input_unit(*expr, names);
                            }
                            result
                        };
                        region.formula = Some(result);
                        names.insert(name, index);
                    }
                    ("eval", [expr, rest @ ..]) => {
                        region.label = identifier(*expr).unwrap_or_else(|_| "Результат".into());
                        let result = if disabled {
                            Err("вычисление отключено в исходном листе".into())
                        } else {
                            expression(*expr, names, &mut deps, 0).and_then(|expr| {
                                if let Some(unit) = rest
                                    .iter()
                                    .copied()
                                    .find(|n| named(*n, ML, "unitOverride"))
                                    .and_then(|wrapper| elements(wrapper).next())
                                    .filter(|unit| !named(*unit, ML, "placeholder"))
                                {
                                    let label = unit_label(unit);
                                    region.display_unit =
                                        Some((label, expression(unit, names, &mut deps, 0)?));
                                }
                                Ok(expr)
                            })
                        };
                        region.formula = Some(result);
                    }
                    ("symEval", _) => {
                        region.label = "Символьное вычисление".into();
                        region.formula =
                            Some(Err("символьные вычисления не поддерживаются".into()));
                    }
                    ("apply" | "parens" | "id" | "real", _) => {
                        region.label = "Выражение".into();
                        region.formula = Some(if disabled {
                            Err("вычисление отключено в исходном листе".into())
                        } else {
                            expression(statement, names, &mut deps, 0)
                        });
                    }
                    (tag, _) => {
                        return Err(format!(
                            "регион {} содержит неподдерживаемую операцию <{tag}>",
                            region.source_id
                        ))
                    }
                }
            }
            Some(tag @ ("graph" | "plot" | "xyPlot" | "image" | "picture")) => {
                region.text = Some(format!("Блок <{tag}> пропущен"));
            }
            Some("pageBreak") => region.text = Some("Разрыв страницы".into()),
            Some(tag) => {
                return Err(format!(
                    "регион {} содержит неизвестный блок <{tag}>",
                    region.source_id
                ))
            }
            None => region.text = Some("Пустой регион".into()),
        }
        deps.sort_unstable();
        deps.dedup();
        for dep in deps {
            self.dependents[dep].push(index);
        }
        self.regions.push(region);
        Ok(())
    }

    fn evaluate(&mut self, index: usize) -> bool {
        if let Some(formula) = &self.regions[index].formula {
            let result = match (self.overrides[index], formula) {
                (Some(value), _) => Ok(value),
                (None, Ok(expr)) => expr.eval(&self.cache),
                (None, Err(reason)) => Err(reason.clone()),
            };
            self.cache[index] = Some(result);
            return true;
        }
        false
    }

    pub fn full(&mut self) -> usize {
        for index in self.dirty.drain(..) {
            self.queued[index] = false;
        }
        (0..self.regions.len())
            .filter(|&index| self.evaluate(index))
            .count()
    }

    pub fn incremental(&mut self) -> usize {
        self.dirty.sort_unstable();
        let count = self.dirty.len();
        for cursor in 0..count {
            let index = self.dirty[cursor];
            self.evaluate(index);
            self.queued[index] = false;
        }
        self.dirty.clear();
        count
    }

    fn replace(&mut self, index: usize, number: Option<f64>, unit: Option<&str>) -> Calc<bool> {
        let original = self
            .regions
            .get(index)
            .and_then(|region| region.input_unit)
            .ok_or("выберите номер изменяемого входа (*)")?;
        let replacement = if let Some(number) = number {
            let scale = match unit {
                Some(name) => {
                    Value::constant(name).ok_or_else(|| format!("неизвестная единица {name}"))?
                }
                None => original,
            };
            if !original.compatible(scale) {
                return Err("единица не совпадает с размерностью входа".into());
            }
            Some(scale.multiply_number(number)?)
        } else {
            None
        };
        let changed = replacement != self.overrides[index];
        self.overrides[index] = replacement;
        Ok(changed)
    }

    pub fn set(&mut self, index: usize, number: Option<f64>, unit: Option<&str>) -> Calc<()> {
        if self.replace(index, number, unit)? && !self.queued[index] {
            self.queued[index] = true;
            let mut cursor = self.dirty.len();
            self.dirty.push(index);
            while cursor < self.dirty.len() {
                let region = self.dirty[cursor];
                cursor += 1;
                for &dependent in &self.dependents[region] {
                    if !self.queued[dependent] {
                        self.queued[dependent] = true;
                        self.dirty.push(dependent);
                    }
                }
            }
        }
        Ok(())
    }

    pub fn set_and_recalculate_all(&mut self, index: usize, number: f64) -> Calc<usize> {
        self.replace(index, Some(number), None)?;
        Ok(self.full())
    }

    pub fn editable(&self, index: usize) -> bool {
        self.regions[index].input_unit.is_some()
    }

    pub fn first_difference(&self, other: &Self) -> Option<usize> {
        self.cache
            .iter()
            .zip(&other.cache)
            .position(|(left, right)| left != right)
    }

    pub fn display(&self, index: usize) -> Calc<String> {
        let value = self.cache[index]
            .as_ref()
            .ok_or("нет численного результата")?
            .as_ref()
            .map_err(Clone::clone)?;
        if let Some((label, unit)) = &self.regions[index].display_unit {
            let number = value.in_units(unit.eval(&self.cache)?)?;
            return Ok(format!("{} {label}", display_number(number)));
        }
        Ok(value.to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn recalculates_only_dependent_regions_and_matches_full_calculation() {
        let mut incremental = Sheet::import(crate::DEMO).unwrap();
        let mut full = Sheet::import(crate::DEMO).unwrap();
        assert_eq!(incremental.full(), 7);
        assert_eq!(full.full(), 7);
        for pressure in [60000., 32000., 13000.] {
            assert!(incremental.set(1, Some(pressure), Some("mm")).is_err());
            incremental.set(1, Some(pressure), Some("N")).unwrap();
            full.set(1, Some(pressure), Some("N")).unwrap();
            assert_eq!(incremental.incremental(), 3);
            assert_eq!(full.full(), 7);
            assert_eq!(incremental.cache, full.cache);
            let result = incremental.display(5).unwrap();
            let (number, unit) = result.split_once(' ').unwrap();
            assert!((number.parse::<f64>().unwrap() - pressure / 40000.).abs() < 1e-12);
            assert_eq!(unit, "MPa");
        }
        incremental.set(1, None, None).unwrap();
        assert_eq!(incremental.incremental(), 3);
        assert_eq!(incremental.incremental(), 0);
        let result = incremental.cache[1].as_ref().unwrap().as_ref().unwrap();
        assert_eq!(result.number, 40000.);
    }

    #[test]
    fn sorts_aligned_regions_and_keeps_prior_bindings() {
        let mut sheet = Sheet::import(r#"
            <worksheet xmlns="http://schemas.mathsoft.com/worksheet30"
                       xmlns:m="http://schemas.mathsoft.com/math30">
              <regions>
                <region align-y="1" left="5"><math><m:eval><m:id>x</m:id></m:eval></math></region>
                <region align-y="2" left="2"><math><m:define><m:id>x</m:id><m:real>8</m:real></m:define></math></region>
                <region align-y="1" left="0"><math><m:define><m:id>x</m:id><m:real>2</m:real></m:define></math></region>
                <region align-y="2" left="9"><math><m:eval><m:id>x</m:id></m:eval></math></region>
              </regions>
            </worksheet>"#).unwrap();
        assert_eq!(sheet.full(), 4);
        assert_eq!(sheet.display(1).unwrap(), "2");
        assert_eq!(sheet.display(3).unwrap(), "8");
        sheet.set(0, Some(7.), None).unwrap();
        assert_eq!(sheet.incremental(), 2);
        assert_eq!(sheet.display(1).unwrap(), "7");
        assert_eq!(sheet.display(3).unwrap(), "8");
    }

    #[test]
    fn propagates_an_unsupported_definition_to_its_consumers() {
        let xml = r#"
            <worksheet xmlns="http://schemas.mathsoft.com/worksheet30"
                       xmlns:m="http://schemas.mathsoft.com/math30">
              <regions>
                <region top="1"><math><m:provenance><m:define><m:id>x</m:id><m:matrix /></m:define></m:provenance></math></region>
                <region top="2"><math><m:eval><m:id>x</m:id></m:eval></math></region>
                <region top="3"><math><m:eval><m:real>42</m:real><m:result><m:real>7</m:real></m:result></m:eval></math></region>
              </regions>
            </worksheet>"#;
        let mut sheet = Sheet::import(xml).unwrap();
        sheet.full();
        assert!(sheet.display(0).unwrap_err().contains("matrix"));
        assert!(sheet.display(1).unwrap_err().ends_with("#1"));
        assert_eq!(sheet.display(2).unwrap(), "42");
        assert!(Sheet::import(&xml.replace("m:define", "m:globalDefine")).is_err());
    }
}
