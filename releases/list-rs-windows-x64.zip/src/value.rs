use std::fmt;

pub type Calc<T> = Result<T, String>;
const ZERO: [i16; 7] = [0; 7];
const BASE: [&str; 7] = ["m", "kg", "s", "A", "K", "mol", "cd"];

pub fn display_number(number: f64) -> String {
    let scientific = format!("{number:.11e}");
    let (mantissa, exponent) = scientific
        .split_once('e')
        .expect("формат e содержит показатель степени");
    let exponent: i32 = exponent.parse().expect("показатель степени — целое число");
    if (-4..12).contains(&exponent) {
        let precision = (11 - exponent) as usize;
        let decimal = format!("{number:.precision$}");
        if precision > 0 {
            return decimal.trim_end_matches('0').trim_end_matches('.').into();
        }
        return decimal;
    }
    format!(
        "{}e{exponent}",
        mantissa.trim_end_matches('0').trim_end_matches('.')
    )
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Value {
    pub number: f64,
    dimensions: [i16; 7],
}

impl Value {
    pub fn scalar(number: f64) -> Calc<Self> {
        Self::new(number, ZERO)
    }

    fn new(number: f64, dimensions: [i16; 7]) -> Calc<Self> {
        if !number.is_finite() {
            return Err("результат вне области действительных конечных чисел".into());
        }
        Ok(Self { number, dimensions })
    }

    pub fn constant(name: &str) -> Option<Self> {
        let (number, dimensions) = match name {
            "m" => (1., [1, 0, 0, 0, 0, 0, 0]),
            "mm" => (0.001, [1, 0, 0, 0, 0, 0, 0]),
            "cm" => (0.01, [1, 0, 0, 0, 0, 0, 0]),
            "km" => (1000., [1, 0, 0, 0, 0, 0, 0]),
            "kg" => (1., [0, 1, 0, 0, 0, 0, 0]),
            "g" => (0.001, [0, 1, 0, 0, 0, 0, 0]),
            "s" => (1., [0, 0, 1, 0, 0, 0, 0]),
            "ms" => (0.001, [0, 0, 1, 0, 0, 0, 0]),
            "min" => (60., [0, 0, 1, 0, 0, 0, 0]),
            "hr" => (3600., [0, 0, 1, 0, 0, 0, 0]),
            "A" => (1., [0, 0, 0, 1, 0, 0, 0]),
            "K" => (1., [0, 0, 0, 0, 1, 0, 0]),
            "mol" => (1., [0, 0, 0, 0, 0, 1, 0]),
            "cd" => (1., [0, 0, 0, 0, 0, 0, 1]),
            "N" => (1., [1, 1, -2, 0, 0, 0, 0]),
            "kN" => (1000., [1, 1, -2, 0, 0, 0, 0]),
            "Pa" => (1., [-1, 1, -2, 0, 0, 0, 0]),
            "kPa" => (1000., [-1, 1, -2, 0, 0, 0, 0]),
            "MPa" => (1e6, [-1, 1, -2, 0, 0, 0, 0]),
            "bar" => (1e5, [-1, 1, -2, 0, 0, 0, 0]),
            "J" => (1., [2, 1, -2, 0, 0, 0, 0]),
            "W" => (1., [2, 1, -3, 0, 0, 0, 0]),
            "L" => (0.001, [3, 0, 0, 0, 0, 0, 0]),
            "rad" => (1., ZERO),
            "deg" => (std::f64::consts::PI / 180., ZERO),
            "π" => (std::f64::consts::PI, ZERO),
            "e" => (std::f64::consts::E, ZERO),
            _ => return None,
        };
        Some(Self { number, dimensions })
    }

    pub fn compatible(self, other: Self) -> bool {
        self.dimensions == other.dimensions
    }

    pub fn multiply_number(self, number: f64) -> Calc<Self> {
        Self::new(self.number * number, self.dimensions)
    }

    pub fn in_units(self, unit: Self) -> Calc<f64> {
        if !self.compatible(unit) || unit.number == 0. {
            return Err("несовместимая или нулевая единица результата".into());
        }
        Ok(Self::scalar(self.number / unit.number)?.number)
    }

    pub fn binary(self, op: &str, other: Self) -> Calc<Self> {
        match op {
            "plus" | "minus" => {
                if !self.compatible(other) {
                    return Err("несовместимые размерности при сложении или вычитании".into());
                }
                let other = if op == "plus" {
                    other.number
                } else {
                    -other.number
                };
                Self::new(self.number + other, self.dimensions)
            }
            "mult" | "scale" | "div" => {
                let divide = op == "div";
                if divide && other.number == 0. {
                    return Err("деление на ноль".into());
                }
                let mut dimensions = ZERO;
                for (out, (left, right)) in dimensions
                    .iter_mut()
                    .zip(self.dimensions.into_iter().zip(other.dimensions))
                {
                    *out = if divide {
                        left.checked_sub(right)
                    } else {
                        left.checked_add(right)
                    }
                    .ok_or("слишком большая степень единицы")?;
                }
                let number = if divide {
                    self.number / other.number
                } else {
                    self.number * other.number
                };
                Self::new(number, dimensions)
            }
            "pow" => {
                if other.dimensions != ZERO {
                    return Err("показатель степени должен быть безразмерным".into());
                }
                let mut dimensions = ZERO;
                for (out, original) in dimensions.iter_mut().zip(self.dimensions) {
                    let exponent = f64::from(original) * other.number;
                    if exponent.fract() != 0. || exponent.abs() > f64::from(i16::MAX) {
                        return Err(
                            "результат требует дробных или слишком больших степеней единиц".into(),
                        );
                    }
                    *out = exponent as i16;
                }
                Self::new(self.number.powf(other.number), dimensions)
            }
            _ => Err(format!("неподдерживаемая операция {op}")),
        }
    }

    pub fn unary(self, op: &str) -> Calc<Self> {
        match op {
            "neg" | "minus" => return self.multiply_number(-1.),
            "abs" => return Self::new(self.number.abs(), self.dimensions),
            "sqrt" => return self.binary("pow", Self::scalar(0.5)?),
            _ if self.dimensions != ZERO => {
                return Err(format!("{op} требует безразмерный аргумент"))
            }
            _ => {}
        }
        let number = match op {
            "sin" => self.number.sin(),
            "cos" => self.number.cos(),
            "tan" => self.number.tan(),
            "exp" => self.number.exp(),
            "ln" => self.number.ln(),
            _ => return Err(format!("неподдерживаемая функция {op}")),
        };
        Self::scalar(number)
    }
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", display_number(self.number))?;
        for (unit, exponent) in BASE.into_iter().zip(self.dimensions) {
            match exponent {
                0 => {}
                1 => write!(f, " {unit}")?,
                _ => write!(f, " {unit}^{exponent}")?,
            }
        }
        Ok(())
    }
}
