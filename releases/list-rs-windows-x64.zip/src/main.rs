mod sheet;
mod value;

use sheet::Sheet;
use std::io::{self, BufRead, Read, Write};
use std::path::Path;
use std::process::ExitCode;
use std::time::{Duration, Instant};
use value::Calc;

const DEMO: &str = include_str!("../examples/pressure.xmcd");
const LIMIT: u64 = 32 * 1024 * 1024;
const HELP: &str = "list-rs [путь.xmcd] [--once]\n\n\
    list               Показать значения и сообщения импорта\n\
    set НОМЕР ЧИСЛО    Изменить вход (*) в его исходных единицах\n\
    set НОМЕР ЧИСЛО ЕД Изменить вход с явной единицей, например kN\n\
    reset НОМЕР        Вернуть исходное значение\n\
    bench НОМЕР A B    Сравнить два способа пересчёта при значениях A и B\n\
    help               Показать команды\n\
    quit               Выйти";

fn read_xml(path: &Path) -> Calc<String> {
    let file = std::fs::File::open(path).map_err(|error| format!("{}: {error}", path.display()))?;
    let mut bytes = Vec::new();
    file.take(LIMIT + 1)
        .read_to_end(&mut bytes)
        .map_err(|error| error.to_string())?;
    if bytes.len() as u64 > LIMIT {
        return Err("размер XMCD превышает 32 МиБ".into());
    }
    if let Some(xml) = bytes
        .strip_prefix(&[0xff, 0xfe])
        .or_else(|| bytes.strip_prefix(&[0xfe, 0xff]))
    {
        let little_endian = bytes[0] == 0xff;
        let words = xml.chunks_exact(2);
        if !words.remainder().is_empty() {
            return Err("неполный символ UTF-16".into());
        }
        let words: Vec<_> = words
            .map(|pair| {
                let pair = [pair[0], pair[1]];
                if little_endian {
                    u16::from_le_bytes(pair)
                } else {
                    u16::from_be_bytes(pair)
                }
            })
            .collect();
        return String::from_utf16(&words).map_err(|error| error.to_string());
    }
    let start = if bytes.starts_with(&[0xef, 0xbb, 0xbf]) {
        3
    } else {
        0
    };
    String::from_utf8(bytes.split_off(start))
        .map_err(|_| "ожидается XMCD в кодировке UTF-8 или UTF-16 с BOM".into())
}

fn list(sheet: &Sheet) -> usize {
    let mut issues = 0;
    for (index, region) in sheet.regions.iter().enumerate() {
        let number = index + 1;
        let source = &region.source_id;
        if let Some(text) = &region.text {
            println!("  #{number:<3} [{source}] {text}");
            continue;
        }
        let editable = if sheet.editable(index) { '*' } else { ' ' };
        let label = &region.label;
        match sheet.display(index) {
            Ok(result) => println!("{editable} #{number:<3} [{source}] {label} = {result}"),
            Err(reason) => {
                issues += 1;
                println!("! #{number:<3} [{source}] {label} — {reason}");
            }
        }
    }
    if issues > 0 {
        println!("Регионов с ошибкой или неподдерживаемой формулой: {issues}");
    }
    issues
}

fn region_number(token: &str) -> Calc<usize> {
    token
        .parse::<usize>()
        .ok()
        .and_then(|number| number.checked_sub(1))
        .ok_or_else(|| "укажите номер региона, начиная с 1".into())
}

fn number(token: &str) -> Calc<f64> {
    token
        .replace(',', ".")
        .parse::<f64>()
        .ok()
        .filter(|n| n.is_finite())
        .ok_or_else(|| format!("некорректное число {token}"))
}

fn benchmark(xml: &str, index: usize, a: f64, b: f64) -> Calc<()> {
    if a == b {
        return Err("для сравнения нужны два разных значения".into());
    }
    let mut cached = Sheet::import(xml)?;
    let mut full = Sheet::import(xml)?;
    cached.full();
    full.full();

    for value in [a, b] {
        cached.set(index, Some(value), None)?;
        cached.incremental();
        full.set_and_recalculate_all(index, value)?;
        if let Some(region) = cached.first_difference(&full) {
            return Err(format!("расхождение в регионе #{}", region + 1));
        }
    }

    let mut cached_elapsed = Duration::ZERO;
    let mut full_elapsed = Duration::ZERO;
    let mut cached_count = 0;
    let mut full_count = 0;
    let iterations = 300;
    for step in 0..iterations {
        let value = if step % 2 == 0 { a } else { b };
        let start = Instant::now();
        cached.set(index, Some(value), None)?;
        cached_count = cached.incremental();
        cached_elapsed += start.elapsed();
        let start = Instant::now();
        full_count = full.set_and_recalculate_all(index, value)?;
        full_elapsed += start.elapsed();
    }
    println!("Идентичные результаты обоих режимов для двух входных значений.");
    println!("Зависимый пересчёт: {cached_count} из {full_count} формул за одно изменение.");
    println!("Среднее за {iterations} изменений входа с пересчётом, без импорта и печати:");
    println!(
        "  зависимый {:>11.3} мкс",
        cached_elapsed.as_secs_f64() * 1e6 / f64::from(iterations)
    );
    println!(
        "  полный    {:>11.3} мкс",
        full_elapsed.as_secs_f64() * 1e6 / f64::from(iterations)
    );
    Ok(())
}

fn process(sheet: &mut Sheet, xml: &str, command: &str) -> Calc<bool> {
    let tokens: Vec<_> = command.split_whitespace().collect();
    match tokens.as_slice() {
        [] => {}
        ["list"] => {
            list(sheet);
        }
        ["help"] => println!("{HELP}"),
        ["quit" | "exit"] => return Ok(false),
        ["bench", index, a, b] => benchmark(xml, region_number(index)?, number(a)?, number(b)?)?,
        ["set", index, value, unit @ ..] if unit.len() <= 1 => {
            sheet.set(
                region_number(index)?,
                Some(number(value)?),
                unit.first().copied(),
            )?;
            println!("Пересчитано формул: {}", sheet.incremental());
            list(sheet);
        }
        ["reset", index] => {
            sheet.set(region_number(index)?, None, None)?;
            println!("Пересчитано формул: {}", sheet.incremental());
            list(sheet);
        }
        _ => return Err("неизвестная команда или неверные аргументы. Введите help".into()),
    }
    Ok(true)
}

fn run() -> Calc<bool> {
    let mut path = None;
    let mut once = false;
    for arg in std::env::args_os().skip(1) {
        if arg == "--help" || arg == "-h" {
            println!("{HELP}");
            return Ok(true);
        }
        if arg == "--once" {
            once = true;
        } else if path.is_none() {
            path = Some(arg);
        } else {
            return Err("укажите один путь к листу и, при необходимости, --once".into());
        }
    }
    let title = path.as_deref().map(|path| path.to_string_lossy());
    let xml = if let Some(path) = &path {
        read_xml(Path::new(path))?
    } else {
        DEMO.into()
    };
    let start = Instant::now();
    let mut sheet = Sheet::import(&xml)?;
    let import_time = start.elapsed();
    let start = Instant::now();
    let count = sheet.full();
    let calc_time = start.elapsed();
    println!(
        "Лист · {}",
        title.as_deref().unwrap_or("Давление под опорой (демо)")
    );
    println!(
        "Импорт {:.3} мс. Полный расчёт {:.3} мс ({count} формул).",
        import_time.as_secs_f64() * 1e3,
        calc_time.as_secs_f64() * 1e3
    );
    let issues = list(&sheet);
    if once {
        return Ok(issues == 0);
    }
    println!("* — изменяемый вход. Команды: help, list, set, reset, bench, quit.");
    let mut stdin = io::stdin().lock();
    let mut command = String::new();
    loop {
        print!("> ");
        io::stdout().flush().map_err(|error| error.to_string())?;
        command.clear();
        if stdin
            .read_line(&mut command)
            .map_err(|error| error.to_string())?
            == 0
        {
            break;
        }
        match process(&mut sheet, &xml, &command) {
            Ok(true) => {}
            Ok(false) => break,
            Err(reason) => eprintln!("Ошибка: {reason}"),
        }
    }
    Ok(true)
}

fn main() -> ExitCode {
    match run() {
        Ok(true) => ExitCode::SUCCESS,
        Ok(false) => ExitCode::from(2),
        Err(reason) => {
            eprintln!("Ошибка: {reason}");
            ExitCode::FAILURE
        }
    }
}
